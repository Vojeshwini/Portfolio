
#Plant-Selling-Ecommerce-Website

Create a complete responsive online ecommerce website design for beginers using html css and vanilla javascript step by step.

The main feature of this website are:

✔ Responsive sticky triple header / navbar with toggle menu bar effect.
   
✔ Responsive shopping cart box.

✔ Responsive home with touch slider effect using swipper.js

✔ Responsive banner card section using flexbox.

✔ Responsive category card section using flexbox.

✔ Responsive product card section using flexbox.

✔ Responsive deal section with count down effect using flexbox.

✔ Responsive and animated contact form section using flexbox.

✔ Responsive footer section using flexbox.

Resource: https://www.youtube.com/watch?v=OQbgfxff06s

Key: #Ecommerce-Website, #Plant-shop, #FrontEnd